# LLAPI

LiteLoaderQQNT插件，给其他插件提供一些API

[插件用法](https://llapi.srap.link/docs/LLAPI.html)